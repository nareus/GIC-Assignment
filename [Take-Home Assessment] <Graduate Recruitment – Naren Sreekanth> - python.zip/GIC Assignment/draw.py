"""File containing Draw class to manage the draw"""

import random

class Draw:
    def __init__(self):
        self.winning_numbers = sorted(random.sample(range(1, 16), 5))

    # Check number of matching numbers
    def check_ticket(self, ticket):
        return len(set(ticket.numbers) & set(self.winning_numbers))

    # Print winning numbers
    def print_numbers(self):
        return ", ".join(map(str, self.numbers))