# Application Design

Design Choices (Classes Used):

1. Ticket: Represents a single raffle ticket with randomly generated numbers.
2. TicketList: Manages the collection of tickets for multiple users.
3. Draw: Handles the drawing of winning numbers.
4. RaffleApp: The main application class that orchestrates the entire raffle process.

Assumptions made:

1. The application does not need to end as there is no process to execute ending the application
2. Users with the same name is treated as the same user, thus adding more than 5 tickets for the same name will not be accepted.

The "Press any key to continue" could not be implemented without external libraries. Thus, the enter key is required to be pressed to proceed in the console when prompted.

# Set Up and Running App

Make sure that python and unittest is installed for this application and your terminal is at the directory of these files. This will run in any terminal (mac terminal is recommended).

Use the following command for python3: python3 main.py

# Running tests

Use the following command to run the tests: python3 -m unittest tests.py
