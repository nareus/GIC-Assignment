"""File containing Raffles App class to initialize and run the draw"""

from ticket import TicketList
from draw import Draw
import os

class RaffleApp:
    def __init__(self):
        self.status = "Draw has not started"
        self.pot = 100
        self.draw = None
        self.ticket_list = TicketList()
        self.winners = {2 : {}, 3: {}, 4: {}, 5: {}}

    
    # Reset raffle after draw is completed
    def reset_raffle(self):
        self.status = "Draw has not started"
        self.pot += 100
        self.draw = None
        self.ticket_list = TicketList()
        self.winners = {2 : {}, 3: {}, 4: {}, 5: {}}

    # Initialise Draw 
    def start_draw(self):
        self.pot = 100
        self.status = f"Draw is ongoing. Raffle pot size is ${self.pot}"
        self.ticket_list.clear()
        self.draw = Draw()
        print(f"New Raffle draw has been started. Initial pot size: ${self.pot}")

    # Buy tickets for the specified User
    def buy_tickets(self, name: str, num_tickets: int):
        # Check if name is extracted properly
        if not name:
            raise ValueError("Name cannot be empty.")
        
        #Check if numbers are within range
        num_tickets = int(num_tickets)
        if num_tickets < 1 or num_tickets > 5:
            raise ValueError("You can only buy between 1 and 5 tickets.")
        self.ticket_list.add_tickets(name, num_tickets)
        cost = num_tickets * 5
        self.pot += cost
        self.status = f"Draw is ongoing. Raffle pot size is ${self.pot}"

    # Generate and display winners and the prizes
    def run_raffle(self):
        if not self.draw:
            raise RuntimeError("You need to start a draw first")
        for name, tickets in self.ticket_list.get_tickets():
            print(name, ticket)
            for ticket in tickets:
                match_count = self.draw.check_ticket(ticket)
                if match_count >= 2:
                    if name not in self.winners[match_count]:
                        self.winners[match_count][name] = [(match_count, ticket)]
                    else:
                        self.winners[match_count][name].append((match_count, ticket))
        
        self.display_results()
        self.reset_raffle()
    
    # Display winners and their winning prize
    def display_results(self):
        print("Running Raffle...")
        print(f"Winning Ticket is {self.draw.winning_numbers}\n")
        if not self.winners:
            print("No winners.")
            return
        
        total_pot = self.pot
        reward_structure = {2: 0.1, 3: 0.15, 4: 0.25, 5: 0.5}
        for match_count in sorted(self.winners.keys(), reverse=False):
            print(f"\nGroup {match_count} Winners:")
            win_count = 0
            for name, tickets in self.winners[match_count].items():
                win_count += len(tickets)
            if win_count == 0:
                print("Nil")
            else:
                for name, tickets in self.winners[match_count].items():
                    percentage = reward_structure.get(match_count, 0)
                    prize = total_pot * percentage / win_count
                    print(f"{name} wins with {match_count} ticket(s) - ${prize:.2f}")

    # Print main menu of raffle app
    def print_menu(self):
        print("Welcome to My Raffle App")
        print(f"Status: {self.status}")
        print("\n[1] Start a new Draw")
        print("[2] Buy tickets")
        print("[3] Run Raffle")

    # Clear content from console 
    def clear_console(self):
        os.system('cls' if os.name == 'nt' else 'clear')

    def press_any_key_to_continue(self):
        input("\nPress any key to return to main menu")

    # Execute option of raffle app from the main menu
    def execute_option(self, choice):
        if choice == '1':
            self.start_draw()
        elif choice == '2':
            if self.draw == None:
                self.clear_console()
                print("Please start a draw first.")
            else:
                prompt = input("Enter your name, no of tickets to purchase\n")
                try:
                    name, num_tickets = map(str.strip, prompt.split(','))
                    self.buy_tickets(name, num_tickets)
                except ValueError as e:
                    print(e)
        elif choice == '3':
            try:
                self.run_raffle()
            except RuntimeError as e:
                print(e)
        else:
            print("Invalid choice, only options from 1 - 3 are available")
        self.press_any_key_to_continue()

    # Main function that runs the raffle app
    def start_main_menu(self):
        while True:
            self.clear_console()
            self.print_menu()
            choice = input()
            self.clear_console()
            self.execute_option(choice)
            