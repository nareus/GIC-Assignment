"""File containing Main App"""

from raffle import RaffleApp

def main():
    event = RaffleApp()
    event.start_main_menu()

if __name__ == "__main__":
    main()