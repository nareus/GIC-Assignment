"""File containing unit tests"""
import unittest
from unittest.mock import patch
import sys

sys.path.append('/mnt/data')

from raffle import RaffleApp

class TestRaffleApp(unittest.TestCase):

    def setUp(self):
        self.raffle = RaffleApp()

    @patch('raffle.Draw')
    def test_start_draw(self, MockDraw):
        mock_draw_instance = MockDraw.return_value
        mock_draw_instance.winning_numbers = [1, 2, 3, 4, 5]

        self.raffle.start_draw()

        self.assertEqual(self.raffle.pot, 100)
        self.assertEqual(self.raffle.status, "Draw is ongoing. Raffle pot size is $100")
        self.assertIsNotNone(self.raffle.draw)
        self.assertEqual(self.raffle.draw.winning_numbers, [1, 2, 3, 4, 5])
        self.assertEqual(len(self.raffle.ticket_list.tickets), 0)

    def test_buy_tickets_valid(self):
        self.raffle.start_draw()
        self.raffle.buy_tickets('Alice', 3)

        self.assertEqual(self.raffle.pot, 115)
        self.assertEqual(self.raffle.ticket_list.num['Alice'], 3)
        self.assertEqual(len(self.raffle.ticket_list.tickets['Alice']), 3)

    def test_buy_tickets_invalid_name(self):
        self.raffle.start_draw()
        with self.assertRaises(ValueError) as context:
            self.raffle.buy_tickets('', 3)
        self.assertTrue("Name cannot be empty." in str(context.exception))

    def test_buy_tickets_invalid_number(self):
        self.raffle.start_draw()
        with self.assertRaises(ValueError) as context:
            self.raffle.buy_tickets('Alice', 6)
        self.assertTrue("You can only buy between 1 and 5 tickets." in str(context.exception))

    @patch('raffle.TicketList')
    @patch('raffle.Draw')
    def test_run_raffle(self, MockDraw, MockTicketList):
        # Create mock instances
        mock_ticket_list_instance = MockTicketList.return_value
        mock_draw_instance = MockDraw.return_value
        
        mock_ticket_list_instance.tickets = {
            'John': [[1, 2, 3, 4, 5]],  # List of lists for John
            'Lee': [[1, 2, 3, 4]],      # List of lists for Lee
            'Ryan': [[1, 2, 3]]         # List of lists for Ryan
        }
        
        mock_draw_instance.winning_numbers = [1, 2, 3, 4, 5]
        
        self.raffle.ticket_list = mock_ticket_list_instance
        self.raffle.draw = mock_draw_instance

        self.raffle.start_draw()
        self.raffle.run_raffle()
        
        self.assertEqual(self.raffle.status, "Draw has not started")


if __name__ == '__main__':
    unittest.main(argv=[''], exit=False)