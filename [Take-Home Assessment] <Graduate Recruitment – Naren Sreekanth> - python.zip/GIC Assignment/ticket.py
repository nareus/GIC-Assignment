"""File containing Ticket and TicketList class to manage users and tickets"""

import random

class Ticket:
    def __init__(self):
        self.numbers = sorted(random.sample(range(1, 16), 5))

    # Prints a sequence of the ticket numbers
    def print_numbers(self):
        return ", ".join(map(str, self.numbers))

    

class TicketList:
    def __init__(self):
        # Mapping of users and tickets
        self.tickets = {}
        #Mapping of users and number of tickets
        self.num = {}

    # Reset ticket list
    def clear(self):
        self.tickets = {}
        self.num = {}

    # get the list of tickets
    def get_tickets(self):
        return self.tickets.items()

    # Create and store tickets for the specified user
    def add_tickets(self, name, num_tickets):
        if name in self.num:
            if self.num[name] + num_tickets > 5:
                raise ValueError("Too many tickets for one user")
            else:
                self.num[name] += num_tickets
        else:
            self.num[name] = num_tickets
        
        for i in range(1, num_tickets + 1):
            ticket = Ticket()
            print(f"Ticket {i}:", ticket.print_numbers())
            if name in self.tickets:
                self.tickets[name].append(ticket)
            else:
                self.tickets[name] = [ticket]

